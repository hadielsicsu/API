document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/animais')
        .then(response => response.json())
        .then(animais => {
            const animalList = document.getElementById('animal-list');
            animais.forEach(animal => {
                const card = document.createElement('div');
                card.classList.add('animal-card');
                card.innerHTML = `
                    <img src="${animal.imageUrl}" alt="${animal.nome}">
                    <h2>${animal.nome}</h2>
                    <p>${animal.descricao}</p>
                `;
                animalList.appendChild(card);
            });
        })
        .catch(error => console.error('Erro ao carregar animais:', error));
});
