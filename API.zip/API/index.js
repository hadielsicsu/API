const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

let animais = [];

// Carregar dados dos animais
fs.readFile('animais.json', 'utf8', (err, data) => {
    if (err) {
        console.error(err);
        return;
    }
    animais = JSON.parse(data);
    console.log('Dados dos animais carregados com sucesso.');
});

// Rota para obter todos os animais
app.get('/api/animais', (req, res) => {
    res.json(animais);
});

// Rota para obter um animal específico
app.get('/api/animais/:id', (req, res) => {
    const animalId = parseInt(req.params.id);
    const animal = animais.find(animal => animal.id === animalId);
    if (!animal) {
        res.status(404).send('Animal não encontrado.');
    } else {
        res.json(animal);
    }
});

// Rota para adicionar um novo animal
app.post('/api/animais', (req, res) => {
    const newAnimal = req.body;
    newAnimal.id = animais.length + 1;
    animais.push(newAnimal);
    saveAnimaisData();
    res.status(201).json(newAnimal);
});

// Rota para atualizar um animal existente
app.put('/api/animais/:id', (req, res) => {
    const animalId = parseInt(req.params.id);
    const updatedAnimal = req.body;
    const index = animais.findIndex(animal => animal.id === animalId);
    if (index === -1) {
        res.status(404).send('Animal não encontrado.');
    } else {
        animais[index] = { ...animais[index], ...updatedAnimal };
        saveAnimaisData();
        res.json(animais[index]);
    }
});

// Rota para excluir um animal
app.delete('/api/animais/:id', (req, res) => {
    const animalId = parseInt(req.params.id);
    const index = animais.findIndex(animal => animal.id === animalId);
    if (index === -1) {
        res.status(404).send('Animal não encontrado.');
    } else {
        animais.splice(index, 1);
        saveAnimaisData();
        res.sendStatus(204);
    }
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});

// Função para salvar os dados dos animais no arquivo JSON
function saveAnimaisData() {
    fs.writeFile('animais.json', JSON.stringify(animais, null, 4), 'utf8', err => {
        if (err) {
            console.error('Erro ao salvar os dados dos animais:', err);
        } else {
            console.log('Dados dos animais salvos com sucesso.');
        }
    });
}
